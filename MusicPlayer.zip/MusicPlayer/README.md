# Music Player

A lightweight Android music player starter project using Kotlin, Jetpack Compose, MediaStore and AndroidX Media3.

## Build
Open this folder in Android Studio (Ladybug or newer), let Gradle sync, then Run.

The app requests audio permission, scans local music through MediaStore, and plays selected tracks through a Media3 MediaSessionService so playback can continue in the background.

## Current features
- Local music library scan
- Song title/artist list
- Media3 playback
- Background playback service
- Audio focus / noisy-audio handling
- Android 13+ READ_MEDIA_AUDIO permission
- Dark Material 3 UI

## Next upgrades
Albums, artists, folders, playlists, queue, shuffle/repeat, album art, lyrics, equalizer, notification/lock-screen controls and gapless playback.
