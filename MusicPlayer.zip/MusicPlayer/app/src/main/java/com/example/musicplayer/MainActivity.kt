package com.example.musicplayer

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors

data class Song(val id: Long, val title: String, val artist: String, val uri: String)

class MainActivity : ComponentActivity() {
    private var controller: MediaController? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) loadAndShow()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val token = SessionToken(this, android.content.ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({ controller = future.get() }, MoreExecutors.directExecutor())

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                MusicScreen(
                    songs = remember { mutableStateListOf<Song>() },
                    onLoad = { requestAudioPermission() },
                    onPlay = { playSong(it) }
                )
            }
        }
    }

    private fun requestAudioPermission() {
        val permission = if (android.os.Build.VERSION.SDK_INT >= 33)
            Manifest.permission.READ_MEDIA_AUDIO
        else
            Manifest.permission.READ_EXTERNAL_STORAGE

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED)
            loadAndShow()
        else
            permissionLauncher.launch(permission)
    }

    private fun loadAndShow() {
        val songs = querySongs()
        val content = window.decorView
        // Recompose by recreating the activity with the loaded library.
        runOnUiThread { 
            setContent {
                MaterialTheme(colorScheme = darkColorScheme()) {
                    MusicScreen(songs, { requestAudioPermission() }, { playSong(it) })
                }
            }
        }
    }

    private fun querySongs(): List<Song> {
        val result = mutableListOf<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        contentResolver.query(collection, projection, selection, null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                result += Song(
                    id,
                    c.getString(titleCol) ?: "Unknown title",
                    c.getString(artistCol) ?: "Unknown artist",
                    ContentUris.withAppendedId(collection, id).toString()
                )
            }
        }
        return result
    }

    private fun playSong(song: Song) {
        controller?.setMediaItem(MediaItem.fromUri(song.uri))
        controller?.prepare()
        controller?.play()
    }

    override fun onDestroy() {
        controller?.release()
        super.onDestroy()
    }
}

@Composable
fun MusicScreen(songs: List<Song>, onLoad: () -> Unit, onPlay: (Song) -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("My Music") }) }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp)
        ) {
            Button(onClick = onLoad, modifier = Modifier.fillMaxWidth()) {
                Text(if (songs.isEmpty()) "Scan music library" else "Refresh library")
            }
            Spacer(Modifier.height(12.dp))
            if (songs.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No music loaded")
                }
            } else {
                Text("${songs.size} songs", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                LazyColumn {
                    items(songs, key = { it.id }) { song ->
                        ListItem(
                            headlineContent = { Text(song.title) },
                            supportingContent = { Text(song.artist) },
                            modifier = Modifier.clickable { onPlay(song) }
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}
